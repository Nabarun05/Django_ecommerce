from django import template
from ecommerce import views
from ecommerce import models

def register(self):
    self.save()
    print(self)