from django import template
from ecommerce import views
from ecommerce import models

register = template.Library()




@register.filter(name='price_total')
def price_total(p,ordercart):
    return p.price * p.quantity