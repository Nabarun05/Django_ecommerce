from django import template
from ecommerce import views
from ecommerce import models

register = template.Library()


@register.filter(name='cart_quantity')
def cart_quantity(p,ordercart):
    print("**************************",p)
    print("**************************",ordercart)
    keys = ordercart.keys()
    for id in keys:
        if int(id) == p.id:
            return ordercart.get(id)
    return 0


@register.filter(name='price_total')
def price_total(p,ordercart):
    return p.Product_price * cart_quantity(p,ordercart)


@register.filter(name='total_cart_price')
def total_cart_price(products,ordercart):

    sum = 0
    for pp in products:
        sum += price_total(pp,ordercart)
    return sum



@register.filter(name='order_status')
def order_status(request):
    
    if request.method == "GET":

        return "Pending"
    else:
        return "Completed"