from django import template
from ecommerce import views
from ecommerce import models

register = template.Library()

@register.filter(name='is_in_cart')
def is_in_cart(p,cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == p.id:
            return True
    return False
    

@register.filter(name='cart_quantity')
def cart_quantity(p,cart):
    print("**************************",p)
    print("**************************",cart)
    keys = cart.keys()
    for id in keys:
        if int(id) == p.id:
            return cart.get(id)
    return 0


@register.filter(name='price_total')
def price_total(p,cart):
    return p.Product_price * cart_quantity(p,cart)


@register.filter(name='total_cart_price')
def total_cart_price(products,cart):

    sum = 0
    for pp in products:
        sum += price_total(pp,cart)
    return sum