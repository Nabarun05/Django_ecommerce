from django.db import models
import datetime


# Create your models here.
class admin(models.Model):

    AdminID= models.IntegerField()
    Name=models.CharField(max_length=50)
    Email=models.EmailField()
    Password=models.CharField(max_length=550)
    class Meta:
	    db_table="Admin"
            

class Customer(models.Model):
    Username = models.CharField(max_length=50)
    Phone = models.CharField(max_length=15)
    Email = models.EmailField()
    Password = models.CharField(max_length=500)
    Lastname = models.CharField(max_length=50,default="")

    class Meta:
            db_table="Customer"

    def register(self):
        self.save()
        print(self)

    
    def isExists(self):

        print(self)
        print(self.Email)
        
        if Customer.objects.filter(Email=self.Email).exists():
                return True
                
        else:
                return False
        
    @staticmethod
    def get_customer_by_emailid(email):

        try:
            
            if Customer.objects.get(Email=email):
                  
                  return Customer.objects.get(Email=email)
            else:
                  return None
        except Customer.DoesNotExist:
            email = None

    @staticmethod
    def get_user_by_id(user_email):

        print("email :",user_email)
        return Customer.objects.filter(Email = user_email)
  

class Register(models.Model):

    RegisID= models.IntegerField()
    Name=models.CharField(max_length=50)
    Email=models.EmailField()
    Password=models.CharField(max_length=550)
    class Meta:
	    db_table="Register"

class Login(models.Model):

    LoginID= models.IntegerField()
    Email=models.EmailField()
    Password=models.CharField(max_length=550)
    class Meta:
	    db_table="Login"



class Product_category(models.Model):

    Product_title = models.CharField(max_length=50)
    Product_Image = models.CharField(max_length=50)
    class Meta:
	    db_table="Product_category"



class Product(models.Model):

    Product_name = models.CharField(max_length=50)
    Product_price = models.IntegerField()
    Product_Desc = models.CharField(max_length=50)
    Product_Image = models.CharField(max_length=50)
    Start_price = models.CharField(max_length=50,default="")
    Product_Brand = models.CharField(max_length=50,default="")
    class Meta:
	    db_table="Product"



class Beauty_Product(models.Model):
    
    Product_name = models.CharField(max_length=50)
    Product_price = models.IntegerField()
    Product_Desc = models.CharField(max_length=50)
    Product_Image = models.CharField(max_length=50)
    Start_price = models.CharField(max_length=50)
    Product_Brand = models.CharField(max_length=50)
    class Meta:
	    db_table="Beauty_Product"
            

class Cart(models.Model):
      
      User_id = models.IntegerField()
      Product_id = models.IntegerField()
      class Meta:
            db_table="Cart"


class Category(models.Model):
      
      Name = models.CharField(max_length=50)
      class Meta:
            db_table="Category"


class Store_product (models.Model):
      
    
    Product_name = models.CharField(max_length=50)
    Product_price = models.IntegerField()
    Product_Desc = models.CharField(max_length=50)
    Product_Image = models.CharField(max_length=50)
    Start_price = models.CharField(max_length=50)
    Product_Brand = models.CharField(max_length=50)
    Category_id = models.IntegerField()

    class Meta:
            db_table="Store_Product"


    @staticmethod
    def get_products_by_id(ids):

        print("ids :",ids)
        return Store_product.objects.filter(id__in = ids)
    
    
  
class Order(models.Model):
      product = models.ForeignKey(Store_product,on_delete=models.CASCADE)
      customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
      quantity = models.IntegerField(default=1)  
      price = models.IntegerField()
      address = models.CharField(max_length=50,default="",blank=True)
      phone = models.CharField(max_length=50,default="",blank=True)
      date = models.DateField(default=datetime.datetime.today)
      

      class Meta:
                db_table="Order"


      def PlaceOrder(self):
                
                self.save()

      @staticmethod
      def get_orders_by_customer_id(userID):
            
            orderList = Order.objects.filter(customer_id = userID)
            lists = list(Order.objects.filter(customer_id = userID).values())
            

            return Order \
                        .objects \
                        .filter(customer = userID)\
                        .order_by('-date')
        


     