from string import digits
from django.shortcuts import render,redirect
from django.http import HttpResponseRedirect,HttpResponse, QueryDict
from .models import Register,admin,Login,Product,Product_category,Beauty_Product,Category,Cart,Store_product,Customer,Order
import random
import math
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib.sessions.backends.db import SessionStore
from django.contrib.sessions.models import Session
from collections import Counter
from django.contrib import messages
from django.views import View
from ecommerce.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
from django import forms

# Create your views here.
def Admin(request):
    
        return render(request,"Admin.html")

@staticmethod
def get_all_products():
    return Store_product.objects.all()

@staticmethod
def get_all_categories():
    return Category.objects.all()

@staticmethod
def get_all_products_by_categoryid(Category_id):
    if Category_id:
        
        return Store_product.objects.filter(Category_id = Category_id)
        
    else:
        return Store_product.objects.all()

def __str__(self):
        return self.name
        
class Index(View):
     
    def get(self,request):
         
        cart = request.session.get('cart')
        

        if not cart:
             
             request.session['cart'] = {}
             request.session['ordercart'] = {}


        objc = Category.objects.all()

        request.GET  
        print(request.GET) #prints empty set as {}

        categoryID= request.GET.get('category')  
        print(categoryID)  #prints None
        
        if categoryID:
        
            products = get_all_products_by_categoryid(categoryID)
            print(products)
            
        else:
            products = get_all_products()     

        print("@@@@@@@@@@@@@@@@@@@@@@@@@",request.session.get('user_email'))
        return render(request,"index.html",{'category':objc,'storeproducts':products})
    


    def post(self,request):
         
        prodct = request.POST.get('product')  #'product' comes from index.html name = "product". product id is coming
        print("prodct :-",prodct)
        cart = request.session.get('cart')
        remove = request.POST.get('remove')
        if cart:
            quantity= cart.get(prodct)
            print("quantity :-",quantity)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(prodct)
                    else:
                        cart[prodct] = quantity - 1

                else:
                    cart[prodct] = quantity+1
            else:
                 cart[prodct] = 1
                 
        else:
            cart = {}
            cart[prodct] = 1

        request.session['cart'] = cart

        print("cart -",request.session['cart']) 
        return redirect('../index')


class Categories(View):

    def get(self,request,id):
 
        objc = Category.objects.all()

        print("************",id)

        products = get_all_products_by_categoryid(id)
        print(products)
        
        return render(request,"category.html",{'category':objc,'storeproducts':products})

    def post(self,request,id):
         
        prodct = request.POST.get('product')  #'product' comes from index.html name = "product". product id is coming
        print("prodct :-",prodct)

        cart = request.session.get('cart')
        remove = request.POST.get('remove')
        if cart:
            quantity= cart.get(prodct)
            print("quantity :-",quantity)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(prodct)
                    else:
                        cart[prodct] = quantity - 1

                else:
                    cart[prodct] = quantity+1
            else:
                 cart[prodct] = 1
                 
        else:
            cart = {}
            cart[prodct] = 1

        request.session['cart'] = cart

        print("cart -",request.session['cart']) 
        return redirect('../index')


def Validatecustomer(request,cust):

    error_msg = None

    if not cust.Username:
            error_msg = "User name Required"
    elif len(cust.Username) < 4:
                error_msg = "User name must be 4 characters long!!"
               
    elif not cust.Phone:
            error_msg = "Phone number Required"
    elif len(cust.Phone) <10:
                error_msg = "Phone must be 10 characters long!!"
             
    elif not cust.Email:
            error_msg = "Email ID Required"
    elif len(cust.Email) <10:
                error_msg = "Email must be 10 characters long!!"
              
    elif not cust.Password:
            error_msg = "Password must be Required"
    elif len(cust.Password) <3:
                error_msg = "Password must be 3 characters long!!"

    elif cust.isExists():
           
            error_msg = "Email Address already registered..!!"
            messages.error(request,'Email Address already registered!!')

    return  error_msg 


def RegisterUser(request):
     
        postData = request.POST
        username = postData.get('username')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        # validation

        value = {
            'username': username,
            'phone': phone,
            'email': email
        }
        
        error_msg = None
        cust = Customer(Username=username,Phone=phone,Email=email,Password=password)
        
        print(cust.Username,cust.Phone,cust.Email,cust.Password)
        error_msg = Validatecustomer(request,cust)
              
        if not error_msg:
           
            cust.register()
            messages.success(request,'User added Successfully!')
            return redirect('../index')
                
        else:
            
            data = {

                        'values' : value,
                        'errors': error_msg

                    }        
                    
           
            return render(request,"signup.html",data)
     
        
class Signup(View):#here Login is a subclass of View
     
     #here we need to override a method which we need to handle
     #here we will override a get method 
     #also post method
     
     def get(self,request):
           return render(request,"signup.html")
     
     def post(self,request):
           return RegisterUser(request)
          
 
class Login(View): #here Login is a subclass of View
     
     #here we need to override a method which we need to handle
     #here we will override a get method 
     #also post method
    return_url = None
    def get(self,request):
           
           Login.return_url = request.GET.get('return_url')

           print("---------same-----------",Login.return_url)
           return render(request,"Login.html")
    
    def post(self,request):
          
        error_msg = None
        
        postData = request.POST
        
        email = postData.get('email')
        password = postData.get('password')
        user = Customer.get_customer_by_emailid(email)
        

        
        if user:

            if user.Password == password:
                  request.session['user_name'] = user.Username
                  request.session['user_email'] = user.Email
                  
                  if Login.return_url:
                       
                       print("---------if-----------",Login.return_url)
                       return HttpResponseRedirect(Login.return_url)
                       
                  else:
                       
                    Login.return_url = None
                    messages.success(request,"Logged in Succesfully!!")
                    return redirect('../index')
                
            else:
                  
                  error_msg = "Invalid Password, please try again!!"
                  messages.error(request,"Invalid Password, please try again!!")
                  
        else:
            
            messages.error(request,"Invalid Email, please try again!!")
            error_msg = "Invalid Email, please try again!!"
        
        return render(request,"Login.html",{'errors': error_msg})


class Cart(View):
     
    @method_decorator(auth_middleware)
    def get(self,request):

        print("@@@@@@@@@@@@@@@@@@@@@@@@",request.session.get('cart'))
        ids = list(request.session.get('cart').keys())
        products = Store_product.get_products_by_id(ids)
        user_email = request.session.get('user_email')
        customer = Customer.get_customer_by_emailid(user_email)
        
        print("ids and products :----------",ids, products,user_email,customer)  
        return render(request,"Cart.html" , {'products' : products, 'customer': customer})


class Checkout(View):
 
    def post(self,request):
          
            cart = request.session.get('cart')
            ordercart = request.session.get('ordercart')


            address= request.POST.get('address')
            phone = request.POST.get('phone')


            request.session['address'] = address
            request.session['phone'] = phone

            print("55555555555555555",request.session['address'],request.session['phone'])

            user_email = request.session.get('user_email')
            products=Store_product.get_products_by_id(list(cart.keys()))
            customer = Customer.get_user_by_id(user_email)

            print("***********address************",address)
            print("***********phone************",phone)

            if ordercart:
                
                ids = list(request.session.get('cart').keys())
                print("#########ids#############",ids)
            
                for i in ids:
                    print("INDIVIDUAL ID",i)
                    if cart:

                        quantity= ordercart.get(i)
                        newquantity = cart.get(i)
                        print(" INDIVIDUAL quantity :-",quantity)
                        print(" INDIVIDUAL newquantity :-",newquantity)
                        if quantity:
                            ordercart[i] = quantity + newquantity
                            print("ordercart[i] :-",ordercart[i])   
                        else:
                                ordercart[i] = 1
                    
                    else:
                        cart = {}
                        cart[i] = 1
            else:
                request.session['ordercart'] = {}
                ordercart = request.session.get('cart')
                request.session['ordercart'] = ordercart

            print("**********cart*************",cart)
            #ordercart = request.session.get('cart')   ## changing here from 'cart' to 'ordercart'
            #print("***********ordercart************",ordercart)
            request.session['ordercart'] = ordercart  ## changing here from 'cart' to 'ordercart'
            print("***********ordercartsession************",request.session['ordercart'])
            request.session['cart'] = {}

            return redirect('../orders', {'productList':products, 'customer': customer})
        

class Orders(View):
     
     @method_decorator(auth_middleware)
     def get(self,request):
        
                address1 = request.session.get('address')
                phone1 = request.session.get('phone')

                
                ids = list(request.session.get('ordercart').keys())
                orders = Store_product.get_products_by_id(ids)
                user_email = request.session.get('user_email')  #by email id we have to get customer id who is login currently
                user = Customer.get_user_by_id(user_email)  # get logged in customer details from customer table
                
                print("ccart :",request.session['ordercart'],ids, orders,user_email,user)
                return render(request, "orders.html", {'customer': user,'productList':orders})
 

class Placeorder(View):
     
    def post(self,request):
          
        ordercart = request.session.get('ordercart')
        print("***********ordercart************",ordercart)

        address = request.session.get('address')
        phone = request.session.get('phone')
        user_email = request.session.get('user_email')
        products=Store_product.get_products_by_id(list(ordercart.keys()))
        customer = Customer.get_user_by_id(user_email)

        print("999999999999999999",address,phone)

        for c in customer:
            
            for p in products:
                
                print("Individualssssssssssssssss ID ", p.id)
                print(ordercart.get(str(p.id)))

                order = Order(customer_id = c.id,
                                    product_id=p.id,
                                    address=address,
                                    phone=phone,
                                    price =p.Product_price,
                                    quantity = ordercart.get(str(p.id)))
                
                print(order.PlaceOrder())
                
        messages.success(request,"Order Placed Succesfully!!")
        return render(request, "orders.html", {'productList':products, 'customer': customer})
      
def Logout(request):
     
    request.session.clear()

    return redirect('../login')

class Store(View):
     
    def get(self,request):
        return render (request, "Store.html")


class OrderList(View):
     
    def post(self,request):

        user_email = request.session.get('user_email')
        customer = Customer.get_user_by_id(user_email)
        ids = list(request.session.get('ordercart').keys())
        products = Store_product.get_products_by_id(ids)

        for c in customer:
            orderdtls = Order.get_orders_by_customer_id(c.id)

        print(orderdtls)
     
        return render(request,"OrderHistory.html",{'customer': customer,'OrderList':orderdtls,'products':products})




 
def Productdetails(request):

    if request.method == "POST":

        pn = request.POST['productname']
        pp = request.POST['productprice']
        pd = request.POST['productDesc']
        pi = request.POST['picture']

        obj = Product.objects.create(Product_name=pn,Product_price=pp,Product_Desc=pd,Product_Image=pi)
        obj.save()
        return redirect('../home')
   
def user_home(request):
    obj= Product_category.objects.all()
    objp=Product.objects.all()
    objbp=Beauty_Product.objects.all()

    return render(request,"User_home.html",{'products':obj,'productsep':objp,'productsbp':objbp})

def add_to_cart_view(request,id):
    obj= Product_category.objects.all()
    objp=Product.objects.all()
    objbp=Beauty_Product.objects.all()
    productID = request.POST.get('product')
    cart = request.session.get('cart')
    if cart:
        quantity = cart.get(productID)
        
        if quantity:
            cart[productID] = quantity+1
        else:
            cart[productID] = 1
        
    else:
       cart ={}
       cart[productID] = 1


    request.session['cart'] = cart
    print("updated cart :",request.session['cart'])
    
    c_cart=len(set(str(request.session['cart']).split(",")))
    print(c_cart)
    
    return render(request,'User_home.html',{'product_count_in_cart':c_cart,'products':obj,'productsep':objp,'productsbp':objbp})

def Customerlogin(request):
    return render(request,"Login.html")

def Custregister(request):
    
    random_str = ""
    for i in range(1,6):

            index = math.floor(random.random() * 10)

            random_str += str(digits[index])
            print("after********************",random_str)
    return render (request,'Registration.html',{"ran":random_str})

def Custadd(request):
    if request.method == "POST":

        nm = request.POST['name']
        em = request.POST['email']
        pwd = request.POST['password']
        Regid = request.POST['userid']

        obj = Register.objects.create(Name=nm,Email=em,Password=pwd,RegisID=Regid)
        obj.save()
        return redirect('../customerlogin')
    else:
        return render (request,'Registration.html') 

def Forgotpwd(request):
    return render (request,"ForgotPassword.html")

@ensure_csrf_cookie
def Signin(request):

    if request.method == "POST":

        response = HttpResponse("Cookie Set")  
        response.set_cookie('cookie_name', 'cookie_value')

        regisId = request.POST['userid']
        pwd = request.POST['password']

        print(regisId,pwd)
        user = Register.objects.get(RegisID=regisId,Password=pwd)
        print(user)

        if user is not None:

            rId = user.RegisID
            nm = user.Name
            request.session["ss_rId"]=rId 
            request.session["ss_nm"]=nm 
            print(nm)
            print('ss_nm')
            return render (request,"User_login.html",{"name":nm})


def Test(request):
    return render (request,"test.html")

def Test2(request):
    return render (request,"test2.html")

def Mainmenu(request):
    return render (request,"Mob_Comp_cat.html")



def cookie_session(request):
    request.session.set_test_cookie()
    return HttpResponse("<h1>dataflair</h1>")
def cookie_delete(request):
    if request.session.test_cookie_worked():
        request.session.delete_test_cookie()
        response = HttpResponse("dataflair<br> cookie createed")
    else:
        response = HttpResponse("Dataflair <br> Your browser doesnot accept cookies")
    return response


def create_session(request):
    request.session['name'] = 'username'
    request.session['password'] = 'password123'
    return HttpResponse("<h1>dataflair<br> the session is set</h1>")

def access_session(request):
    response = "<h1>Welcome to Sessions of dataflair</h1><br>"
    if request.session.get('name'):
        response += "Name : {0} <br>".format(request.session.get('name'))
    if request.session.get('password'):
        response += "Password : {0} <br>".format(request.session.get('password'))
        return HttpResponse(response)
    else:
        return redirect('create/')


def delete_session(request):
    try:
        del request.session['name']
        del request.session['password']
        
    except KeyError:
        pass

    return HttpResponse("<h1>dataflair<br>Session Data cleared</h1>")