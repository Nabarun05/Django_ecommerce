# version 4.2 middleware
#it can change in future

from django.shortcuts import render,redirect

def auth_middleware(get_response):
 
    def middleware(request):

        returnUrl = request.META['PATH_INFO']
        print("********same**********",returnUrl)
        if not request.session.get('user_email'):

            return redirect(f'../login?return_url={returnUrl}')

        print('middleware')
        response = get_response(request)    


        return response

    return middleware