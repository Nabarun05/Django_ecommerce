"""PROJECT_ECOMMERCE URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from ecommerce import views
from ecommerce.views import Login,Signup,Index,Cart,Checkout,Orders,Placeorder,Store,Categories,OrderList



urlpatterns = [
    path('admin/', admin.site.urls),
    path('admins',views.Admin),
    path('customerlogin', views.Customerlogin),
    path('home', views.user_home),
    path('custregister',views.Custregister),
    path('forgotpwd',views.Forgotpwd),
    path('custAdd', views.Custadd),
    path('signin',views.Signin),
    path('productdetails',views.Productdetails),
    path('test',views.Test),
    path('mainmenu',views.Mainmenu),
    path('add_to_cart/<int:id>',views.add_to_cart_view),
    path('testcookie/', views.cookie_session),
    path('deletecookie/', views.cookie_delete),
    path('create/', views.create_session),
    path('access/', views.access_session),
    path('delete/', views.delete_session),
    path('index',Index.as_view()),
    path('category/<int:id>',Categories.as_view()),
    path('signup',Signup.as_view()),
    path('login',Login.as_view()),
    path('logout',views.Logout),
    path('cart',Cart.as_view()),
    path('checkout',Checkout.as_view()),
    path('orders',Orders.as_view()),
    path('placeorder',Placeorder.as_view()),
    path('store',Store.as_view()),
    path('orderlist',OrderList.as_view())
]
